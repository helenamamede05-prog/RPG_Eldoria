package rpg.dominio;

public class Inventario {
    private int quantidadePocoes;
    private Arma armaEquipada;

    public int getQuantidadePocoes() { return quantidadePocoes; }
    public Arma getArmaEquipada() { return armaEquipada; }

    public void adicionarPocao() {
        quantidadePocoes++;
    }

    void consumirPocao() {
        if (quantidadePocoes > 0) {
            quantidadePocoes--;
        }
    }

    public void equipar(Arma arma) {
        armaEquipada = arma;
    }
}
