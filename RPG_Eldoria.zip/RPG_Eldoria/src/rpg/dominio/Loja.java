package rpg.dominio;

public class Loja {
    public boolean comprarPocao(Heroi heroi, Pocao pocao) {
        if (pocao == null || pocao.pontosCura <= 0 || pocao.preco <= 0 || pocao.preco > heroi.ouro) {
            return false;
        }
        heroi.ouro -= pocao.preco;
        heroi.inventario.adicionarPocao();
        return true;
    }

    public boolean comprarArma(Heroi heroi, Arma arma) {
        if (arma == null || arma.bonusAtaque < 0 || arma.preco <= 0 || arma.preco > heroi.ouro) {
            return false;
        }
        heroi.ouro -= arma.preco;
        heroi.inventario.equipar(arma);
        return true;
    }
}
