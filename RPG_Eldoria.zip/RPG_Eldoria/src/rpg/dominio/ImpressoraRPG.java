package rpg.dominio;

public class ImpressoraRPG {
    public void imprimirHeroi(Heroi heroi) {
        System.out.println(heroi.gerarResumo());
    }

    public void imprimirMonstro(Monstro monstro) {
        System.out.println(monstro.gerarResumo());
    }

    public void imprimirInventario(Heroi heroi) {
        Arma arma = heroi.inventario.getArmaEquipada();
        System.out.println("Inventário de " + heroi.getNome());
        System.out.println(arma == null ? "Nenhuma arma equipada" : "Arma equipada: " + arma);
        System.out.println("Poções: " + heroi.inventario.getQuantidadePocoes());
        System.out.println("Ouro disponível: " + heroi.getOuro());
    }
}
