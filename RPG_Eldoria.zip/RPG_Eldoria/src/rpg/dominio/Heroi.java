package rpg.dominio;

public class Heroi {
    String nome;
    int vida, vidaMaxima, ataque, defesa, nivel, experiencia, ouro;
    public Inventario inventario = new Inventario();

    public String getNome() { return nome; }
    public int getVida() { return vida; }
    public int getVidaMaxima() { return vidaMaxima; }
    public int getNivel() { return nivel; }
    public int getExperiencia() { return experiencia; }
    public int getOuro() { return ouro; }

    public boolean estaVivo() { return vida > 0; }

    public int calcularAtaqueTotal() {
        Arma arma = inventario.getArmaEquipada();
        return ataque + (arma == null ? 0 : arma.bonusAtaque);
    }

    public int calcularDano(int defesaInimigo) {
        return Math.max(1, calcularAtaqueTotal() - Math.max(0, defesaInimigo));
    }

    public void receberDano(int dano) {
        if (dano > 0) {
            vida = Math.max(0, vida - dano);
        }
    }

    public void curar(int pontosDeCura) {
        if (pontosDeCura > 0) {
            vida += Math.min(pontosDeCura, vidaMaxima - vida);
        }
    }

    public String gerarResumo() {
        return "%s | Vida: %d/%d | Ataque: %d | Defesa: %d | Nível: %d | XP: %d | Ouro: %d"
                .formatted(nome, vida, vidaMaxima, calcularAtaqueTotal(), defesa, nivel, experiencia, ouro);
    }

    public boolean usarPocao(Pocao pocao) {
        if (pocao == null || pocao.pontosCura <= 0 || !estaVivo()
                || vida == vidaMaxima || inventario.getQuantidadePocoes() == 0) {
            return false;
        }
        curar(pocao.pontosCura);
        inventario.consumirPocao();
        return true;
    }

    public void receberRecompensa(Monstro monstro) {
        if (estaVivo() && monstro.liberarRecompensa()) {
            ouro += monstro.ouroRecompensa;
            experiencia += monstro.experienciaRecompensa;
        }
    }

    public void verificarSubidaDeNivel() {
        while (nivel > 0 && experiencia >= nivel * 100L) {
            experiencia -= nivel * 100;
            nivel++;
            ataque += 3;
            vidaMaxima += 10;
            vida = vidaMaxima;
            System.out.println("Subiu para o nível " + nivel + "!");
        }
    }
}
