package rpg.dominio;

public class Monstro {
    String nome;
    int vida, ataque, defesa, ouroRecompensa, experienciaRecompensa;
    private boolean recompensaEntregue;

    public String getNome() { return nome; }
    public int getVida() { return vida; }
    public boolean estaVivo() { return vida > 0; }

    public int calcularDano(int defesaHeroi) {
        return Math.max(1, ataque - Math.max(0, defesaHeroi));
    }

    public void receberDano(int dano) {
        if (dano > 0) {
            vida = Math.max(0, vida - dano);
        }
    }

    public String gerarResumo() {
        return "%s | Vida: %d | Ataque: %d | Defesa: %d | Recompensa: %d ouro, %d XP"
                .formatted(nome, vida, ataque, defesa, ouroRecompensa, experienciaRecompensa);
    }

    void reiniciarRecompensa() {
        recompensaEntregue = false;
    }

    boolean liberarRecompensa() {
        if (estaVivo() || recompensaEntregue) {
            return false;
        }
        recompensaEntregue = true;
        return true;
    }
}
