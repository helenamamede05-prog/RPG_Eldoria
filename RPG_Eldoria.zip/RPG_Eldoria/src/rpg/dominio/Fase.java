package rpg.dominio;

public class Fase {
    final String nome;
    final Monstro inimigo;
    boolean concluida;

    public Fase(String nome, Monstro inimigo) {
        this.nome = nome;
        this.inimigo = inimigo;
    }

    public String getNome() { return nome; }
    public Monstro getInimigo() { return inimigo; }
}
