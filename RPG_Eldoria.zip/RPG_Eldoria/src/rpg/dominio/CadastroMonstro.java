package rpg.dominio;

public class CadastroMonstro {
    public void cadastrar(Monstro monstro, String nome, int vida, int ataque, int defesa,
                          int ouroRecompensa, int experienciaRecompensa) {
        if (nome == null || nome.isBlank() || vida <= 0 || ataque < 0 || defesa < 0
                || ouroRecompensa < 0 || experienciaRecompensa < 0) {
            throw new IllegalArgumentException("Dados do monstro inválidos.");
        }
        monstro.nome = nome.strip();
        monstro.vida = vida;
        monstro.ataque = ataque;
        monstro.defesa = defesa;
        monstro.ouroRecompensa = ouroRecompensa;
        monstro.experienciaRecompensa = experienciaRecompensa;
        monstro.reiniciarRecompensa();
    }
}
