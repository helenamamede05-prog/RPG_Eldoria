package rpg.dominio;

public class Arma {
    final String nome;
    final int bonusAtaque;
    final int preco;

    public Arma(String nome, int bonusAtaque, int preco) {
        this.nome = nome;
        this.bonusAtaque = bonusAtaque;
        this.preco = preco;
    }

    public String getNome() { return nome; }

    @Override
    public String toString() {
        return "%s (+%d de ataque, %d ouro)".formatted(nome, bonusAtaque, preco);
    }
}
