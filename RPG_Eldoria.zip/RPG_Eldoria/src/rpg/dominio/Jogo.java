package rpg.dominio;

import java.util.Scanner;

public class Jogo {
    private final String titulo = "A Jornada de Eldoria";
    private final ImpressoraRPG impressora = new ImpressoraRPG();
    private final Batalha batalha = new Batalha();
    private final Loja loja = new Loja();
    private final Pocao pocao = new Pocao("Poção Pequena", 20, 10);
    private final Arma madeira = new Arma("Espada de Madeira", 2, 15);
    private final Arma ferro = new Arma("Espada de Ferro", 8, 40);
    private Heroi heroi;
    public Fase[] fases;
    private int indiceFase;
    private boolean emExecucao;

    public void configurar(Heroi heroi, Fase[] fases) {
        if (heroi == null || fases == null || fases.length == 0) {
            throw new IllegalArgumentException("Informe o herói e as fases.");
        }
        this.heroi = heroi;
        this.fases = fases;
        indiceFase = 0;
        emExecucao = true;
    }

    public void exibirBoasVindas() {
        System.out.println("Bem-vindo ao RPG: " + titulo + "!");
        System.out.println(heroi.nome + ", as criaturas invadiram o Reino de Eldoria.");
        System.out.println("Atravesse a floresta e a caverna para derrotar o Guardião Sombrio.");
    }

    public void exibirMenu() {
        System.out.println("""
                ================================
                       RPG - ELDORIA
                ================================

                1 - Ver status do herói
                2 - Explorar / Lutar
                3 - Abrir inventário
                4 - Visitar loja
                5 - Sair do jogo

                Escolha uma opção:""");
    }

    public int lerOpcao(Scanner scanner) {
        return lerOpcaoNoIntervalo(scanner, 1, 5);
    }

    static int lerOpcaoNoIntervalo(Scanner scanner, int minimo, int maximo) {
        while (scanner.hasNextLine()) {
            try {
                int opcao = Integer.parseInt(scanner.nextLine().strip());
                if (opcao >= minimo && opcao <= maximo) {
                    return opcao;
                }
            } catch (NumberFormatException ex) {
                // Entradas não numéricas recebem a mesma mensagem e podem ser repetidas.
            }
            System.out.println("Opção inválida. Tente novamente.");
        }
        return -1;
    }

    public void executarOpcao(int opcao, Scanner scanner) {
        switch (opcao) {
            case 1 -> impressora.imprimirHeroi(heroi);
            case 2 -> explorar(scanner);
            case 3 -> impressora.imprimirInventario(heroi);
            case 4 -> abrirLoja(scanner);
            case 5, -1 -> emExecucao = false;
            default -> System.out.println("Opção inválida. Tente novamente.");
        }
    }

    public void iniciar(Scanner scanner) {
        exibirBoasVindas();
        while (emExecucao && heroi.estaVivo()) {
            exibirMenu();
            executarOpcao(lerOpcao(scanner), scanner);
        }
        if (!heroi.estaVivo()) {
            System.out.println("""
                    =====================================
                                 GAME OVER
                    =====================================

                    Seu herói foi derrotado.

                    Sua jornada terminou...
                    =====================================""");
        }
    }

    private void explorar(Scanner scanner) {
        Fase fase = fases[indiceFase];
        System.out.println("Fase: " + fase.nome);
        impressora.imprimirMonstro(fase.inimigo);
        if (batalha.iniciarBatalha(heroi, fase.inimigo, pocao, scanner)) {
            avancarFase();
        }
    }

    private void abrirLoja(Scanner scanner) {
        int opcao;
        do {
            System.out.println("Ouro disponível: " + heroi.ouro);
            System.out.printf("1 - %s%n2 - %s%n3 - %s%n4 - Voltar%n", pocao, madeira, ferro);
            opcao = lerOpcaoNoIntervalo(scanner, 1, 4);
            boolean comprado = switch (opcao) {
                case 1 -> loja.comprarPocao(heroi, pocao);
                case 2 -> loja.comprarArma(heroi, madeira);
                case 3 -> loja.comprarArma(heroi, ferro);
                default -> false;
            };
            if (opcao >= 1 && opcao <= 3) {
                System.out.println(comprado ? "Compra efetuada." : "Compra recusada.");
            }
        } while (opcao >= 1 && opcao <= 3);
    }

    public void avancarFase() {
        if (indiceFase >= fases.length || !heroi.estaVivo()) {
            return;
        }
        Fase fase = fases[indiceFase];
        if (fase.concluida || fase.inimigo.estaVivo()) {
            return;
        }
        heroi.receberRecompensa(fase.inimigo);
        System.out.printf("Vitória! Recompensa: %d ouro e %d XP.%n",
                fase.inimigo.ouroRecompensa, fase.inimigo.experienciaRecompensa);
        heroi.verificarSubidaDeNivel();
        fase.concluida = true;
        indiceFase++;
        if (indiceFase == fases.length) {
            emExecucao = false;
            System.out.println("""
                    =====================================
                               PARABÉNS, HERÓI!
                    =====================================

                    Você derrotou o Guardião Sombrio!

                    O Reino de Eldoria foi salvo!

                    Obrigado por jogar.
                    =====================================""");
        }
    }
}
