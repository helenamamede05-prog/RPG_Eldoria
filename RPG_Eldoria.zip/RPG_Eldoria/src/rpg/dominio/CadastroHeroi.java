package rpg.dominio;

public class CadastroHeroi {
    public void cadastrar(Heroi heroi, String nome, int vidaMaxima, int ataque, int defesa) {
        if (nome == null || nome.isBlank() || vidaMaxima <= 0 || ataque < 0 || defesa < 0) {
            throw new IllegalArgumentException("Nome, vida máxima, ataque ou defesa inválidos.");
        }
        heroi.nome = nome.strip();
        heroi.vida = vidaMaxima;
        heroi.vidaMaxima = vidaMaxima;
        heroi.ataque = ataque;
        heroi.defesa = defesa;
        heroi.nivel = 1;
        heroi.experiencia = 0;
        heroi.ouro = 30;
        heroi.inventario = new Inventario();
        heroi.inventario.adicionarPocao();
        heroi.inventario.adicionarPocao();
    }
}
