package rpg.dominio;

import java.util.Scanner;

public class Batalha {
    public void atacarComHeroi(Heroi heroi, Monstro monstro) {
        if (heroi.estaVivo() && monstro.estaVivo()) {
            int dano = heroi.calcularDano(monstro.defesa);
            monstro.receberDano(dano);
            System.out.printf("%s causou %d de dano em %s.%n", heroi.nome, dano, monstro.nome);
        }
    }

    public void atacarComMonstro(Monstro monstro, Heroi heroi) {
        if (heroi.estaVivo() && monstro.estaVivo()) {
            int dano = monstro.calcularDano(heroi.defesa);
            heroi.receberDano(dano);
            System.out.printf("%s causou %d de dano em %s.%n", monstro.nome, dano, heroi.nome);
        }
    }

    public void executarTurno(Heroi heroi, Monstro monstro) {
        atacarComHeroi(heroi, monstro);
        atacarComMonstro(monstro, heroi);
        exibirVidas(heroi, monstro);
    }

    public boolean iniciarBatalha(Heroi heroi, Monstro monstro, Pocao pocao, Scanner scanner) {
        while (heroi.estaVivo() && monstro.estaVivo()) {
            System.out.println("1 - Atacar\n2 - Usar poção\n3 - Fugir");
            int opcao = Jogo.lerOpcaoNoIntervalo(scanner, 1, 3);
            switch (opcao) {
                case 1 -> executarTurno(heroi, monstro);
                case 2 -> {
                    if (heroi.usarPocao(pocao)) {
                        System.out.println("Poção utilizada.");
                        atacarComMonstro(monstro, heroi);
                        exibirVidas(heroi, monstro);
                    } else {
                        System.out.println("Não foi possível usar a poção.");
                    }
                }
                case 3, -1 -> {
                    System.out.println("Você fugiu do combate.");
                    return false;
                }
            }
        }
        return heroi.estaVivo() && !monstro.estaVivo();
    }

    private void exibirVidas(Heroi heroi, Monstro monstro) {
        System.out.printf("Vida de %s: %d | Vida de %s: %d%n",
                heroi.nome, heroi.vida, monstro.nome, monstro.vida);
    }
}
