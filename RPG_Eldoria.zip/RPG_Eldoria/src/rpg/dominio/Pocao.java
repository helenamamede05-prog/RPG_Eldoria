package rpg.dominio;

public class Pocao {
    final String nome;
    final int pontosCura;
    final int preco;

    public Pocao(String nome, int pontosCura, int preco) {
        this.nome = nome;
        this.pontosCura = pontosCura;
        this.preco = preco;
    }

    @Override
    public String toString() {
        return "%s (%d de cura, %d ouro)".formatted(nome, pontosCura, preco);
    }
}
