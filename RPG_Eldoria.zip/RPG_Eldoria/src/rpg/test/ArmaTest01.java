package rpg.test;

import rpg.dominio.*;

public class ArmaTest01 {
    public static void main(String[] args) {
        Arma madeira = new Arma("Espada de Madeira", 2, 15);
        Arma ferro = new Arma("Espada de Ferro", 8, 40);
        System.out.println(madeira);
        System.out.println(ferro);
        Heroi heroi = Fixtures.heroi();
        Fixtures.verificar(heroi.calcularDano(3) == 12, "Ataque básico");
        heroi.inventario.equipar(madeira);
        Fixtures.verificar(heroi.calcularAtaqueTotal() == 17, "Bônus da arma");
    }
}
