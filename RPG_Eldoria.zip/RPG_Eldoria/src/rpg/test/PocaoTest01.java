package rpg.test;

import rpg.dominio.*;

public class PocaoTest01 {
    public static void main(String[] args) {
        Pocao pequena = new Pocao("Poção Pequena", 20, 10);
        Pocao grande = new Pocao("Poção Grande", 50, 25);
        System.out.println(pequena);
        System.out.println(grande);
        Heroi heroi = Fixtures.heroi();
        Fixtures.verificar(!heroi.usarPocao(pequena) && heroi.inventario.getQuantidadePocoes() == 2,
                "Vida cheia sem consumo");
        heroi.receberDano(30);
        Fixtures.verificar(!heroi.usarPocao(new Pocao("Inválida", 0, 1)) && heroi.getVida() == 70
                && heroi.inventario.getQuantidadePocoes() == 2, "Cura inválida");
        Fixtures.verificar(heroi.usarPocao(pequena) && heroi.getVida() == 90, "Herói ferido");
        Fixtures.verificar(heroi.usarPocao(grande) && heroi.getVida() == 100, "Cura limitada");
        heroi.receberDano(10);
        Fixtures.verificar(!heroi.usarPocao(pequena) && heroi.getVida() == 90, "Sem poção");
    }
}
