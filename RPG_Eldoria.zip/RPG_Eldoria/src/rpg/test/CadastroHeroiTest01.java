package rpg.test;

import rpg.dominio.*;

public class CadastroHeroiTest01 {
    public static void main(String[] args) {
        Heroi heroi = Fixtures.heroi();
        CadastroHeroi cadastro = new CadastroHeroi();
        Runnable[] entradasInvalidas = {
            () -> cadastro.cadastrar(heroi, " ", 100, 15, 5),
            () -> cadastro.cadastrar(heroi, "Luna", 0, 15, 5),
            () -> cadastro.cadastrar(heroi, "Luna", 100, -1, 5),
            () -> cadastro.cadastrar(heroi, "Luna", 100, 15, -1)
        };
        for (Runnable entrada : entradasInvalidas) {
            try {
                entrada.run();
                throw new AssertionError("Cadastro aceitou dados inválidos.");
            } catch (IllegalArgumentException ex) {
                Fixtures.verificar(heroi.getNome().equals("Arthur") && heroi.getVida() == 100,
                        "Cadastro anterior preservado");
            }
        }
        System.out.println("Quatro cadastros inválidos rejeitados.");
    }
}
