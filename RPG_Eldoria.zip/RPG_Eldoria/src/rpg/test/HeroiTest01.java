package rpg.test;

import rpg.dominio.*;

public class HeroiTest01 {
    public static void main(String[] args) {
        Heroi arthur = Fixtures.heroi();
        Heroi luna = Fixtures.heroi("Luna", 80, 20, 3);
        ImpressoraRPG impressora = new ImpressoraRPG();
        impressora.imprimirHeroi(arthur);
        impressora.imprimirHeroi(luna);
        Fixtures.verificar(arthur.getVida() == 100 && luna.getVida() == 80, "Heróis independentes");
        System.out.println("Vida antes do dano: " + arthur.getVida());
        arthur.receberDano(10);
        System.out.println("Vida depois do dano: " + arthur.getVida());
        arthur.curar(20);
        Fixtures.verificar(arthur.getVida() == 100 && arthur.estaVivo(), "Limite da cura");
        arthur.receberDano(100);
        Fixtures.verificar(!arthur.estaVivo() && luna.estaVivo(), "Estado de vida");
    }
}
