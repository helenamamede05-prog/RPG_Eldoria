package rpg.test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import rpg.dominio.Fase;
import rpg.dominio.Heroi;
import rpg.dominio.Jogo;

public class JogoQATest01 {
    public static void main(String[] args) {
        String vitoria = capturar(() -> {
            try (Scanner scanner = new Scanner("\nArthur\nabc\n@\n100\n4\n1\n2\n4\n3\n2\n1\n2\n1\n1\n1\n2\n1\n1\n1\n2\n1\n1\n1\n1\n1\n")) {
                JogoTest01.executar(scanner);
            }
        });
        conferir("QA-001", vitoria, "Tente novamente:", "Bem-vindo", "Arthur");
        conferir("QA-002", vitoria, "Compra efetuada.", "Poções: 3");
        conferir("QA-003", vitoria, "Arma equipada: Espada de Madeira (+2 de ataque");
        conferir("QA-004", vitoria, "Poção utilizada.");
        conferir("QA-005", vitoria, "Vitória! Recompensa: 25 ouro e 60 XP.", "Caverna dos Ossos");
        conferir("QA-008", vitoria, "Subiu para o nível 2!");
        conferir("QA-009", vitoria, "Opção inválida. Tente novamente.");
        conferir("QA-010", vitoria, "Castelo das Sombras", "Você derrotou o Guardião Sombrio!",
                "O Reino de Eldoria foi salvo!");

        Heroi ferido = Fixtures.heroi();
        ferido.receberDano(99);
        conferir("QA-006", partida(ferido, "2\n1\n"), "GAME OVER");

        Heroi fugitivo = Fixtures.heroi();
        String fuga = partida(fugitivo, "2\n3\n5\n");
        conferir("QA-007", fuga, "Você fugiu do combate.");
        Fixtures.verificar(fugitivo.getOuro() == 30 && fugitivo.getExperiencia() == 0
                && !fuga.contains("Recompensa: 25 ouro e 60 XP.\n\n"), "Fuga sem prêmio");
    }

    private static String partida(Heroi heroi, String comandos) {
        return capturar(() -> {
            Jogo jogo = new Jogo();
            Fase[] fases = JogoTest01.criarFases();
            jogo.configurar(heroi, fases);
            try (Scanner scanner = new Scanner(comandos)) {
                jogo.iniciar(scanner);
            }
        });
    }

    private static String capturar(Runnable executar) {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        PrintStream original = System.out;
        try (PrintStream saida = new PrintStream(buffer, true, StandardCharsets.UTF_8)) {
            System.setOut(saida);
            executar.run();
        } finally {
            System.setOut(original);
        }
        return buffer.toString(StandardCharsets.UTF_8);
    }

    private static void conferir(String id, String saida, String... resultados) {
        for (String resultado : resultados) {
            Fixtures.verificar(saida.contains(resultado), id + " — saída ausente: " + resultado
                    + System.lineSeparator() + saida);
        }
        System.out.println(id + " — Aprovado");
    }
}
