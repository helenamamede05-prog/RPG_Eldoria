package rpg.test;

import rpg.dominio.*;

public class BatalhaTest01 {
    public static void main(String[] args) {
        Batalha batalha = new Batalha();
        Heroi heroi = Fixtures.heroi();
        Monstro monstro = Fixtures.goblin();
        while (heroi.estaVivo() && monstro.estaVivo()) {
            batalha.executarTurno(heroi, monstro);
        }
        heroi.receberRecompensa(monstro);
        heroi.receberRecompensa(monstro);
        Fixtures.verificar(monstro.getVida() == 0 && heroi.getVida() == 98
                && heroi.getOuro() == 55 && heroi.getExperiencia() == 60, "Vitória e recompensa única");
        heroi = Fixtures.heroi();
        heroi.receberDano(99);
        monstro = Fixtures.goblin();
        batalha.executarTurno(heroi, monstro);
        Fixtures.verificar(heroi.getVida() == 0 && monstro.getVida() == 16, "Herói derrotado");
        batalha.atacarComHeroi(heroi, monstro);
        Fixtures.verificar(monstro.getVida() == 16, "Herói morto não ataca");
        heroi = Fixtures.heroi();
        monstro.receberDano(15);
        batalha.executarTurno(heroi, monstro);
        Fixtures.verificar(monstro.getVida() == 0 && heroi.getVida() == 100, "Monstro morto não ataca");
        heroi.receberDano(-100);
        monstro.receberDano(-100);
        Fixtures.verificar(heroi.getVida() == 100 && monstro.getVida() == 0
                && heroi.calcularDano(200) == 1 && monstro.calcularDano(200) == 1, "Limites do dano");
    }
}
