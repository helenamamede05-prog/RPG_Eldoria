package rpg.test;

import rpg.dominio.*;

public class InventarioTest01 {
    public static void main(String[] args) {
        Heroi heroi = Fixtures.heroi();
        ImpressoraRPG impressora = new ImpressoraRPG();
        impressora.imprimirInventario(heroi);
        heroi.inventario.equipar(new Arma("Espada de Madeira", 2, 15));
        impressora.imprimirInventario(heroi);
        Fixtures.verificar(heroi.inventario.getQuantidadePocoes() == 2
                && heroi.inventario.getArmaEquipada().getNome().equals("Espada de Madeira"), "Inventário");
    }
}
