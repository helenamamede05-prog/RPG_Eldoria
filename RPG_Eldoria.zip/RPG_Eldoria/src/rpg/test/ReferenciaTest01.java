package rpg.test;

import rpg.dominio.*;

public class ReferenciaTest01 {
    public static void main(String[] args) {
        Heroi heroi = Fixtures.heroi();
        Monstro original = Fixtures.goblin();
        Monstro mesmaReferencia = original;
        System.out.println("Vida antes: " + original.getVida());
        new Batalha().atacarComHeroi(heroi, original);
        System.out.printf("Vida depois: original %d, referência %d%n", original.getVida(), mesmaReferencia.getVida());
        Fixtures.verificar(original == mesmaReferencia && original.getVida() == 16, "Referência alterada");
    }
}
