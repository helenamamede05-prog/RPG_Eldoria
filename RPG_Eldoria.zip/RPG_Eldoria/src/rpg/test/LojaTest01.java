package rpg.test;

import rpg.dominio.*;

public class LojaTest01 {
    public static void main(String[] args) {
        Heroi heroi = Fixtures.heroi();
        Loja loja = new Loja();
        Fixtures.verificar(loja.comprarPocao(heroi, new Pocao("Poção Pequena", 20, 10))
                && heroi.getOuro() == 20 && heroi.inventario.getQuantidadePocoes() == 3, "Compra de poção");
        Fixtures.verificar(!loja.comprarArma(heroi, new Arma("Ferro", 8, 40)), "Ouro insuficiente");
        Fixtures.verificar(!loja.comprarPocao(heroi, new Pocao("Inválida", 20, -1))
                && heroi.getOuro() == 20, "Preço inválido");
        Fixtures.verificar(loja.comprarArma(heroi, new Arma("Madeira", 2, 15))
                && heroi.calcularAtaqueTotal() == 17 && heroi.getOuro() == 5, "Equipamento e saldo");
    }
}
