package rpg.test;

import rpg.dominio.*;

public class MonstroTest01 {
    public static void main(String[] args) {
        Fase[] fases = JogoTest01.criarFases();
        ImpressoraRPG impressora = new ImpressoraRPG();
        for (Fase fase : fases) {
            impressora.imprimirMonstro(fase.getInimigo());
        }
        Monstro goblin = fases[0].getInimigo();
        Fixtures.verificar(goblin.calcularDano(2) == 4 && goblin.calcularDano(100) == 1, "Dano do monstro");
        goblin.receberDano(30);
        Fixtures.verificar(!goblin.estaVivo() && fases[1].getInimigo().estaVivo(), "Vida dos monstros");
    }
}
