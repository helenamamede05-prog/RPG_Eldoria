package rpg.test;

import rpg.dominio.*;

public class NivelTest01 {
    public static void main(String[] args) {
        verificar(0, 1, 0);
        verificar(99, 1, 99);
        verificar(100, 2, 0);
        verificar(330, 3, 30);
    }

    private static void verificar(int xp, int nivel, int restante) {
        Heroi heroi = Fixtures.heroi();
        heroi.receberDano(1);
        Monstro monstro = Fixtures.monstro("Treino", 1, 1, 0, 0, xp);
        monstro.receberDano(1);
        heroi.receberRecompensa(monstro);
        heroi.verificarSubidaDeNivel();
        Fixtures.verificar(heroi.getNivel() == nivel && heroi.getExperiencia() == restante
                && heroi.getVidaMaxima() == 100 + (nivel - 1) * 10
                && heroi.calcularAtaqueTotal() == 15 + (nivel - 1) * 3
                && heroi.getVida() == (nivel == 1 ? 99 : heroi.getVidaMaxima()), "XP " + xp);
    }
}
