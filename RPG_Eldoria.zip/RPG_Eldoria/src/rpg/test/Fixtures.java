package rpg.test;

import rpg.dominio.CadastroHeroi;
import rpg.dominio.CadastroMonstro;
import rpg.dominio.Heroi;
import rpg.dominio.Monstro;

final class Fixtures {
    private Fixtures() {}

    static Heroi heroi(String nome, int vida, int ataque, int defesa) {
        Heroi heroi = new Heroi();
        new CadastroHeroi().cadastrar(heroi, nome, vida, ataque, defesa);
        return heroi;
    }

    static Monstro monstro(String nome, int vida, int ataque, int defesa, int ouro, int xp) {
        Monstro monstro = new Monstro();
        new CadastroMonstro().cadastrar(monstro, nome, vida, ataque, defesa, ouro, xp);
        return monstro;
    }

    static Heroi heroi() { return heroi("Arthur", 100, 15, 5); }
    static Monstro goblin() { return monstro("Goblin", 30, 6, 1, 25, 60); }

    static void verificar(boolean condicao, String cenario) {
        if (!condicao) {
            throw new AssertionError(cenario);
        }
    }
}
