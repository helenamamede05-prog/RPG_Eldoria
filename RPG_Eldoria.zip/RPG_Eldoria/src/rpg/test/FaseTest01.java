package rpg.test;

import rpg.dominio.*;

public class FaseTest01 {
    public static void main(String[] args) {
        Fase floresta = JogoTest01.criarFases()[0];
        System.out.println(floresta.getNome() + " — " + floresta.getInimigo().getNome());
        Fixtures.verificar(floresta.getInimigo().getNome().equals("Goblin"), "Inimigo associado");
    }
}
