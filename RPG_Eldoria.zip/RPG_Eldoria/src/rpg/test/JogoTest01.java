package rpg.test;

import java.util.Scanner;
import rpg.dominio.*;

public class JogoTest01 {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            executar(scanner);
        }
    }

    static void executar(Scanner scanner) {
        Heroi heroi = new Heroi();
        System.out.println("Informe o nome do herói:");
        while (scanner.hasNextLine()) {
            try {
                new CadastroHeroi().cadastrar(heroi, scanner.nextLine(), 100, 15, 5);
                Jogo jogo = new Jogo();
                jogo.configurar(heroi, criarFases());
                jogo.iniciar(scanner);
                return;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage() + " Tente novamente:");
            }
        }
    }

    static Fase[] criarFases() {
        return new Fase[] {
            new Fase("Floresta Sombria", Fixtures.monstro("Goblin", 30, 6, 1, 25, 60)),
            new Fase("Caverna dos Ossos", Fixtures.monstro("Esqueleto", 45, 9, 2, 40, 70)),
            new Fase("Castelo das Sombras", Fixtures.monstro("Guardião Sombrio", 75, 12, 3, 80, 150))
        };
    }
}
