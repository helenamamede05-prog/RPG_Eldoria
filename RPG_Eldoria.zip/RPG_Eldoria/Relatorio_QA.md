# Relatório de QA — RPG Eldoria

Testes executados com `rpg.test.JogoQATest01` em classes compiladas com `javac --release 17`. Os dez casos integrados foram aprovados. As onze classes de teste específicas também terminaram sem falha.

| ID | Funcionalidade | Entrada | Resultado esperado | Resultado obtido | Status | Observações |
|---|---|---|---|---|---|---|
| QA-001 | Cadastro do herói | Nome vazio, depois Arthur | Rejeitar o vazio e cadastrar Arthur | Nova tentativa solicitada e boas-vindas a Arthur | Aprovado | Nenhum defeito observado no cenário. |
| QA-002 | Compra de poção | Comprar uma poção com 30 de ouro e abrir inventário | Comprar e subir de 2 para 3 poções | Compra confirmada e inventário com 3 poções | Aprovado | Nenhum defeito observado no cenário. |
| QA-003 | Compra de arma | Comprar Espada de Madeira e abrir inventário | Equipar a espada com bônus +2 | Inventário exibiu a Espada de Madeira com +2 de ataque | Aprovado | Nenhum defeito observado no cenário. |
| QA-004 | Uso de poção | Atacar o Goblin e usar poção após o contra-ataque | Usar a poção com o herói ferido | O combate registrou a utilização da poção | Aprovado | Nenhum defeito observado no cenário. |
| QA-005 | Vitória em batalha | Derrotar o Goblin e explorar novamente | Conceder 25 ouro e 60 XP e liberar a caverna | Recompensa exibida e Caverna dos Ossos aberta | Aprovado | Nenhum defeito observado no cenário. |
| QA-006 | Derrota em batalha | Herói com 1 de vida ataca o Goblin | Contra-ataque derrota o herói e encerra a partida | Mensagem GAME OVER exibida | Aprovado | Nenhum defeito observado no cenário. |
| QA-007 | Fuga | Fugir do Goblin em uma partida nova | Retornar ao menu sem ouro nem XP adicionais | Fuga exibida, com 30 de ouro e 0 XP preservados | Aprovado | Nenhum defeito observado no cenário. |
| QA-008 | Subida de nível | Vencer o Goblin e o Esqueleto e acumular 130 XP | Atingir o nível 2 | Mensagem de evolução para o nível 2 exibida | Aprovado | Nenhum defeito observado no cenário. |
| QA-009 | Entrada inválida no menu | Digitar abc, @ e 100 antes de uma opção válida | Informar o erro e aceitar nova tentativa | Mensagem de opção inválida exibida e o jogo prosseguiu | Aprovado | Nenhum defeito observado no cenário. |
| QA-010 | Vitória contra o chefe | Chegar ao castelo e atacar até derrotar o Guardião | Exibir conclusão da história e encerrar a partida | Castelo acessado, Guardião derrotado e Eldoria salva | Aprovado | Nenhum defeito observado no cenário. |
